package com.baiwang.init.api;

import org.springframework.web.bind.annotation.RequestMapping;

public interface HealthController {

    @RequestMapping(value = "/bwhealth")
    public String bwhealth();
}
