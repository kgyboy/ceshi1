package com.baiwang.init.model.demo;

/**
 * @ProjectName: init-api
 * @Package: com.baiwang.init.model.demo
 * @ClassName: DemoBean
 * @Description: java类作用描述
 * @Author: Lance cui
 * @CreateDate: 2018/12/5 5:25 PM
 * @Version: 1.0
 */
public class DemoBean {

    private int id;

    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
