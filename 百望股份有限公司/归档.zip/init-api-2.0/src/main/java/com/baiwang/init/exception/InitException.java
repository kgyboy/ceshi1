/*
 * @项目名称: Moirai
 * @文件名称: MoiraiException.java
 * @Date: 17-11-4 下午4:52
 * @author Lance cui
 *
 */

package com.baiwang.init.exception;


import com.baiwang.init.enumutil.InitErrorEnum;
import com.baiwang.moirai.exception.MoiraiBaseException;

/**
 * 自定义业务异常-通用系统异常，表示所有未知原因引起的系统异常
 * 
 * @author wuyuegang
 * 
 */
public class InitException extends MoiraiBaseException
{
    /**
     * auto generate
     */
    private static final long serialVersionUID = 8912473097017237022L;

    /**
     * construct
     *
     * @param errorCode
     * @param errorMsg
     */
    public InitException(String errorCode, String errorMsg)
    {
        super(errorCode, errorMsg);
    }

    public InitException(InitErrorEnum error)
    {
        super(error.getCode(),error.getMsg());
    }

    public InitException(InitErrorEnum error, String requestID)
    {
        super(error.getCode(),error.getMsg(),requestID);
    }
}
