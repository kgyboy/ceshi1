package com.baiwang.init.api.demo;

import com.baiwang.init.model.demo.DemoBean;
import com.baiwang.moirai.model.common.BWJsonResult;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @ProjectName: jewel
 * @Package: com.baiwang.jewel.api.oauth
 * @ClassName: JewelOauthLoginSvc
 * @Description: java类作用描述
 * @Author: Lance cui
 * @CreateDate: 2018/11/26 1:49 PM
 * @Version: 1.0
 */
@RequestMapping("/demo")
public interface InitDemoApi {

    @RequestMapping(value = "/test", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    BWJsonResult<DemoBean> test(HttpServletRequest request, HttpServletResponse response);

}
