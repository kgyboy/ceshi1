/*
 * @项目名称: INIT
 * @文件名称: InitErrorEnum.java
 * @Date: 17-11-4 下午4:40
 * @author Lance cui
 *
 */

package com.baiwang.init.enumutil;

import com.baiwang.moirai.enumutil.IBwBaseEnum;
import org.springframework.util.StringUtils;

/**
 * 全局错误码枚举，数字编码不允许重复，请按照升序进行排列,此错
 * <p>
 * 误码和错误信息是直接返回给最终用户的，请写清楚错误原因,更好
 * <p>
 * 的来指导用户进行后续的操作。
 * <p>
 * 统一使用四位错误码，第一位标识模块
 * 1-租户
 * 2-组织机构
 * 3-用户
 * 4-角色
 * 5-产品，资源
 * 6-登录相关
 *
 * @author Lance cui
 */
public enum InitErrorEnum implements IBwBaseEnum {


    /**
     * 默认错误，系统异常
     * 0-系统级
     */

    INIT_SYSTEM_ERROR("0000", "聚宝盆渠道管理系统异常"),

    INIT_LOGIN_ERROR("0001", "用户没有登录，请重新登录。"),

    INIT_PASSWORD_ERROR("0002", "用户名或密码错误。"),

    INIT_PARAMS_MISS_ERROR("0003", "参数缺失！"),

    INIT_SMSCODE_SEND_ERROR("0004", "短信验证码发送失败！"),

    INIT_DB_ERROR("0011", "操作数据库错误"),

    INIT_DB_NULL("0012", "查询数据不存在"),

    TINE_OUT_ERROR("0013", "调用外部服务器超时");


    private String msg;

    private String code;

    /**
     * getByCode:(根据code获取枚举). <br/>
     * (如果code为空，返回null).<br/>
     *
     * @param code
     * @return
     * @author wuyuegang
     * @since JDK 1.8
     */
    public static InitErrorEnum getByCode(String code) {
        if (StringUtils.isEmpty(code)) {
            return null;
        }
        for (InitErrorEnum errorEnum : InitErrorEnum.values()) {
            if (errorEnum.getCode().equals(code)) {
                return errorEnum;
            }
        }
        return null;
    }

    /**
     * Creates a new instance of INITErrorEnum.
     *
     * @param code
     * @param msg
     */
    private InitErrorEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    @Override
    public String getMsg() {
        return this.msg;
    }

    @Override
    public String getCode() {
        return this.code;
    }
}
