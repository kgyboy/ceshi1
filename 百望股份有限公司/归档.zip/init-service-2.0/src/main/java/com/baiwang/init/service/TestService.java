package com.baiwang.init.service;

public interface TestService {
}
