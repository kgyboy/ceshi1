package com.baiwang.init.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.concurrent.TimeUnit;


public class RedisUtils {

    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    /**
     * set
     *
     * @param redisKey key
     * @param object   value
     * @param seconds  超时时间
     */
    public void set(String redisKey, String object, long seconds) {
        if (object != null) {
            if (seconds != -1) {
                redisTemplate.opsForValue().set(redisKey, object, seconds, TimeUnit.SECONDS);
            } else {
                redisTemplate.opsForValue().set(redisKey, object);
            }
        }
    }

    /**
     * get方法
     * @param redisKey redisKey
     */

    public <T> T get(String redisKey) {
        Object object = redisTemplate.opsForValue().get(redisKey);
        return (T)object;
    }
}
