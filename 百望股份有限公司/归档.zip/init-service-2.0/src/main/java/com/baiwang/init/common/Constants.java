package com.baiwang.init.common;

public class Constants {

    public static final String sdf_pattern = "yyyy-MM-dd HH:mm:ss";

    public static final String rtnCode = "rtnCode";

    public static final String rtnMsg = "rtnMsg";

    public static final String rtnData = "rtnData";

}
