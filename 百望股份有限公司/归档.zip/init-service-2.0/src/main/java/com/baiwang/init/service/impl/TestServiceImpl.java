package com.baiwang.init.service.impl;

import com.baiwang.init.service.TestService;

public class TestServiceImpl implements TestService {
}
