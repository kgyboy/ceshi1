package com.baiwang.init.mapper;

public interface TestMapper {
}
