package com.baiwang.init.feignclient;

import com.baiwang.seqnum.feign.SeqnumFeign;
import org.springframework.cloud.netflix.feign.FeignClient;

/**
 * 序列号生成
 * @author  zjt 2017-11-2
 */
@FeignClient(value = "seqnum")
public interface SeqnumFeignClient extends SeqnumFeign {

}